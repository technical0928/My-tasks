import inquirer from "inquirer";
import fs from 'fs'

//Question 10
let FILE = "library.json"
//load books
function loadBook() {
    if (!fs.existsSync(FILE)) {
        return []
    }
    let data = fs.readFileSync(FILE, 'utf-8')
    return JSON.parse(data)
}

//Save books

function saveBook(book) {
    fs.writeFileSync(FILE, JSON.stringify(book, null, 2))
}




async function main() {
    let Books = loadBook()
    let question = await inquirer.prompt([
        {
            type: "rawlist",
            name: "choose",
            message: "Choose the one",
            choices: [
                { name: "Add Book", value: "1" },
                { name: "View all books", value: "2" },
                { name: "Mark as Complete", value: "3" },
                { name: "Exit", value: "4" },
            ]
        }
    ])

    if (question.choose === "1") {
        await addBook(Books)
    }
    else if (question.choose === "2") {
        await viewBooks(Books)
    }
    else if (question.choose === "3") {
        await markAsCompleteBook(Books)
    }
    else if (question.choose === "4") {
        console.log("Good bye")
        process.exit()
    }
}

main()

// Add Books
async function addBook(Books) {
    let addBook = await inquirer.prompt([
        {
            type: "input",
            name: "name",
            message: "Enter your Book ",
            validate: function (value) {
                if (value.trim() === "") return "Please enter your Book"
                return true
            }
        }
    ])

    Books.push({
        id: Books.length + 1,
        name: addBook.name,

    })
    saveBook(Books)

    console.log("Book was  added successfully")
    await main()
}

// View Libarary Books
async function viewBooks(Books) {
    if (Books.length === 0) {
        console.log("Books was not found")
        await main()
        return
    }
    let count = 1
    for (let student of Books) {
        console.log(`${count}) Your book is ${student.name}`)
        count++
    }
    saveBook(Books)
    await main()


}

// Mark as complete Books
async function markAsCompleteBook(Books) {
    if (Books.length === 0) {
        console.log("Books was not found")
        await main()
        return
    }

    let count = 1
    for (let student of Books) {
        console.log(`${count}) ${student.name}`)
        count++
    }

    let markBook = await inquirer.prompt([
        {
            type: "input",
            name: "id",
            message: "Enter books number to mark as complete",
            validate: function (value) {
                if (value.trim() === "") return "Please enter number"
                if (value < 1 || value > Books.length) return "Invalid input"
                return true
            }
        }
    ])

    let index = Number(markBook.id) - 1
    Books[index].completed = true

    console.log("Book marked as completed ")
    saveBook(Books)

    await main()
}

