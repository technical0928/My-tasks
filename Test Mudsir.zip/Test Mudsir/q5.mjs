import inquirer from 'inquirer';
import fs from 'fs'



//Question 5
let FILE = "user.txt"
//load notes
function loadNotes() {
    if (!fs.existsSync(FILE)) {
        return []
    }
    let data = fs.readFileSync(FILE, 'utf-8')
    return JSON.parse(data)
}

//Save notes

function saveNotes(khan) {
    fs.writeFileSync(FILE, JSON.stringify(khan, null, 2))
}

async function main() {
    let Notes = loadNotes()
    let question = await inquirer.prompt([
        {
            type: "rawlist",
            name: "choose",
            message: "Choose the one",
            choices: [
                { name: "Add Notes", value: "1" },
                { name: "View Notes", value: "2" },
                { name: "Delete all Notes", value: "3" },
                { name: "Exit", value: "4" },
            ]

        }
    ])

    if (question.choose === "1") {
        await addNotes(Notes)
    } else if (question.choose === "2") {
        await viewNotes(Notes)
    } else if (question.choose === "3") {
        await deleteAllNotes(Notes)
    } else if (question.choose === "4") {
        console.log("Good by")
        process.exit()
    }


}
main()

//Add Notes
async function addNotes(Notes) {
    let addData = await inquirer.prompt([
        {
            type: "input",
            name: "note",
            message: "Enter your notes",
            validate: function (value) {
                if (value.trim() === "") return "Please enter your notes"
                return true
            }
        }

    ])
    Notes.push({
        id: Notes.length + 1,
        note: addData.note,


    })
    console.log("Notes was added was added")
    saveNotes(Notes)

    await main()



}

//view Notes
async function viewNotes(Notes) {
    if (Notes.length === 0) {
        console.log("Notes was not found")
        await main()
        return

    }
    console.table(Notes)

    console.log("//View notes")
    let datas=fs.readFileSync(FILE,'utf-8')
    console.log(datas)


    await main()
}

//Delete all Notes
async function deleteAllNotes() {
    let delNotes = await inquirer.prompt([
        {
            type: "confirm",
            name: "sure",
            message: "Are you sure Delete All notes",
            default: false
        }
    ])
    if (delNotes.sure === true) {
        fs.writeFileSync(FILE,JSON.stringify([],null,2))
        console.log("You deleted all notes")
    }else{
        console.log("Good by")
    }



    await main()

}

