import inquirer from "inquirer";
//Question 1
let todoStores = [];

async function main() {
    let question = await inquirer.prompt([
        {
            type: "rawlist",
            name: "choose",
            message: "Choose the one",
            choices: [
                { name: "Add todo", value: "1" },
                { name: "View todo", value: "2" },
                { name: "Mark as Complete", value: "3" },
                { name: "Delete Todos", value: "4" },
                { name: "Exit", value: "5" },
            ]
        }
    ])

    if (question.choose === "1") {
        await addTodo()
    } 
    else if (question.choose === "2") {
        await viewTodo()
    } 
    else if (question.choose === "3") {
        await markAsComplete()
    } 
    else if (question.choose === "4") {
        await deleteTodo()
    } 
    else if (question.choose === "5") {
        console.log("Good bye")
        process.exit()
    }
}

main()

// Add Todo
async function addTodo() {
    let addTodo = await inquirer.prompt([
        {
            type: "input",
            name: "name",
            message: "Enter your todo",
            validate: function (value) {
                if (value.trim() === "") return "Please enter your todo"
                return true
            }
        }
    ])

    todoStores.push({
        name: addTodo.name,
        
    })

    console.log("Todo added successfully")
    await main()
}

// View Todos
async function viewTodo() {
    if (todoStores.length === 0) {
        console.log("Todo was not found")
        await main()
        return
    }
    let count=1
    for(let todoStore of todoStores){
        console.log(`${count}) Your todo is ${todoStore.name}`)
        count++
    }
    await main()

   
}


// Mark as complete
async function markAsComplete() {
    if (todoStores.length === 0) {
        console.log("Todo was not found")
        await main()
        return
    }

    let count = 1
    for (let todoStore of todoStores) {
        console.log(`${count}) ${todoStore.name}`)
        count++
    }

    let markTodo = await inquirer.prompt([
        {
            type: "input",
            name: "id",
            message: "Enter todo number to mark as complete",
            validate: function (value) {
                if (value.trim() === "") return "Please enter number"
                if (value < 1 || value > todoStores.length) return "Invalid input"
                return true
            }
        }
    ])

    let index = Number(markTodo.id) - 1
    todoStores[index].completed = true

    console.log("Todo marked as completed ")

    await main()
}

// Delete Todo
async function deleteTodo() {

    if (todoStores.length === 0) {
        console.log("Todo was not found")
        await main()
        return
    }

    let count = 1
    for (let todoStore of todoStores) {
        console.log(`${count}) ${todoStore.name}`)
        count++
    }

    let delTodo = await inquirer.prompt([
        {
            type: "input",
            name: "id",
            message: "Enter todo number to delete",
            validate: function (value) {
                if (value.trim() === "") return "Please enter number"
                if (value < 1 || value > todoStores.length) return "Invalid input"
                return true
            }
        }
    ])

    let index = Number(delTodo.id) - 1
    todoStores.splice(index, 1)

    console.log("Todo was deleted")

    await main()
}