import inquirer from "inquirer";
import fs, { readFileSync } from 'fs'


let FILE = "expense.json"

//Load Expense
function loadExpense() {
    if (!fs.existsSync(FILE)) {
        return []
    }
    let data = readFileSync(FILE, 'utf-8')
    return JSON.parse(data)
}

//Save Expense
function saveExpense(khan) {
    fs.writeFileSync(FILE, JSON.stringify(khan, null, 2))
}
async function main() {
    let Expenses = loadExpense()
    let question = await inquirer.prompt([
        {
            type: "rawlist",
            name: "choose",
            message: "Choose one",
            choices: [
                { name: "Add Expense", value: "1" },
                { name: "View summary", value: "2" },
                { name: "View by category", value: "3" },
                { name: "Exit", value: "4" },

            ]
        }
    ])

    if (question.choose === "1") {
        await addExpense(Expenses)
    } else if (question.choose === "2") {
        await viewSummary(Expenses)
    } else if (question.choose === "3") {
        await viewByCategory(Expenses)
    } else if (question.choose === "4") {
        console.log("Good by")
        process.exit()
    }
}
main()

//Add expense
async function addExpense(Expenses) {
    let addData = await inquirer.prompt([
        {
            type: "number",
            name: "amount",
            message: "Enter amount"
        },
        {
            type: "rawlist",
            name: "category",
            message: "Choose the category",
            choices: [
                { name: "Food", value: "Food" },
                { name: "Transport", value: "Transport" },
                { name: "Shopping", value: "Shopping" },
                { name: "Bill", value: "Bill" },
                { name: "Other", value: "Other" },
            ]

        },
        {
            type: "input",
            name: "description",
            message: "Enter description",
            validate: function (value) {
                if (value.trim() === "") "Please enter your description"
                return true
            }
        }
    ])

    Expenses.push({
        id: Expenses.length + 1,
        amount: addData.amount,
        category: addData.category,
        description: addData.description,

    })
    saveExpense(Expenses)
    console.log("Expenses was added")
    await main()

}

//view summary
async function viewSummary(Expenses) {
    if (Expenses.length === 0) {
        console.log("No expenses found")
        await main()
        return
    }
    console.log("/// VIEW SUMMARY ///")
    let totalFood = 0
    let totalTransport = 0
    let totalShopping = 0
    let totalBill = 0
    let totalOther = 0

    for (let student of Expenses) {
        if (student.category === "Food") {
            totalFood += student.amount
        } else if (student.category === "Transport") {
            totalTransport += student.amount
        } else if (student.category === "Shopping") {
            totalShopping += student.amount
        } else if (student.category === "Bill") {
            totalBill += student.amount
        } else if (student.category === "Other") {
            totalOther += student.amount
        }
    }
    console.log("=============================")
    if (totalFood > 0) console.log(`FOOD Rs: ${totalFood}`)
    if (totalTransport > 0) console.log(`Transport Rs: ${totalTransport}`)
    if (totalShopping > 0) console.log(`Shopping Rs: ${totalShopping}`)
    if (totalBill > 0) console.log(`Bill Rs: ${totalBill}`)
    if (totalOther > 0) console.log(`Other Rs: ${totalOther}`)
    console.log("=============================")
    let grandTotal = totalFood + totalTransport + totalShopping + totalBill + totalOther
    console.log(`TOTAL RS: ${grandTotal} `)

    await main()
}

//View by category

async function viewByCategory(Expenses) {
    if (Expenses.length === 0) {
        console.log("No expenses found")
        await main()
        return
    }
    let categoryData = await inquirer.prompt([
        {
            type: "rawlist",
            name: "category",
            message: "Choose the category",
            choices: [
                { name: "Food", value: "Food" },
                { name: "Transport", value: "Transport" },
                { name: "Shopping", value: "Shopping" },
                { name: "Bill", value: "Bill" },
                { name: "Other", value: "Other" },
            ]
        }
    ])

    console.log(`${categoryData} Expense`)
    console.log("===========================")

    let total = 0

    for (let student of Expenses) {
        if (student.category === categoryData.category) {
            console.log(`${student.amount} = ${student.category} `)
            total += student.amount
        }
    }

    if (total.length === 0) {
        console.log("No expense found")
        await main()
        return
    } else {
        console.log("=========================")
        console.log(`Total ${total}`)

    }

    await main()

}

