import inquirer from "inquirer";

//question 6
async function main() {
    let user = await inquirer.prompt([
        {
            type: "number",
            name: "myChoose",
            message: "Enter my number 1 To 100",
            validate: function (value) {
                if (value.length === 0) return "Please enter your number"
                if (value < 1 || value > 100) return "Please enter number 1 TO 100"
                return true
            }
        },
        {
            type: "number",
            name: "userChoose",
            message: "Please user enter your number 1 to 100 about",
            validate: function (value) {
                if (value.length === 0) return "Please enter your number"
                 if (value < 1 || value > 100) return "Please enter number 1 TO 100"
                return true

               
            }

        }
    ])

    if (user.myChoose === user.userChoose) {
        console.log("Congratulation  you are find my  number")
    } else {
        console.log("Wrong guess")
    }


}
main()