import inquirer from 'inquirer';
import fs from 'fs'


//Question 2
let FILE = "student.json"
//load student
function loadstudent() {
    if (!fs.existsSync(FILE)) {
        return []
    }
    let data = fs.readFileSync(FILE, 'utf-8')
    return JSON.parse(data)
}

//Save student

function savestudent(khan) {
    fs.writeFileSync(FILE, JSON.stringify(khan, null, 2))
}

async function main() {
    let students = loadstudent()
    let question = await inquirer.prompt([
        {
            type: "rawlist",
            name: "choose",
            message: "Choose the one",
            choices: [
                { name: "Add Student", value: "1" },
                { name: "View Student", value: "2" },
                { name: "Delete student", value: "3" },
                { name: "Update student", value: "4" },
                { name: "Exit", value: "5" },
            ]

        }
    ])

    if (question.choose === "1") {
        await addStudent(students)
    } else if (question.choose === "2") {
        await viewStudent(students)
    } else if (question.choose === "3") {
        await deleteStudent(students)
    } else if (question.choose === "4") {
        await updateStudent(students)
    } else if (question.choose === "5") {
        console.log("Good by")
        process.exit()
    }


}
main()

//Add Student
async function addStudent(students) {
    let addData = await inquirer.prompt([
        {
            type: "input",
            name: "name",
            message: "Enter your name",
            validate: function (value) {
                if (value.trim() === "") return "Please enter your name"
                return true
            }
        },
        {
            type: "input",
            name: "father",
            message: "Enter your father name",
            validate: function (value) {
                if (value.trim() === "") return "Please enter your father name"
                return true
            }
        },
        {
            type: "number",
            name: "age",
            message: "Enter your age",
            validate: function (value) {
                if (value < 18 || value > 120) return "Please enter age 18 to 120"
                return true
            }
        }
    ])
    students.push({
        id: students.length + 1,
        name: addData.name,
        father: addData.father,
        age: addData.age,

    })
    console.log("Students data was added")
    savestudent(students)

    await main()



}

//view todos
async function viewStudent(students) {
    if (students.length === 0) {
        console.log("Student was not found")
        await main()
        return

    }
    console.table(students)


    await main()
}

//Delete todo
async function deleteStudent(students) {
    if (students.length === 0) {
        console.log("students was not found")
        await main()
    }
    console.table(students)

    let delData = await inquirer.prompt([
        {
            type: "input",
            name: "id",
            message: "Enter id which one data deleted",
            validate: function (value) {
                if (value.trim() === "") return "Please enter id ";
                if (value < 1 || value > students.length) return "Invalid input"
                return true
            }

        }
    ])

    let index = Number(delData.id) - 1
    students.splice(index, 1)

    savestudent(students)
    console.log("student data was deleted")

    await main()

}

//Update student

async function updateStudent(students) {

    if (students.length === 0) {
        console.log("students was not found")
        await main()
    }
    console.table(students)

    let updData = await inquirer.prompt([
        {
            type: "input",
            name: "id",
            message: "Enter id which one data updated",
            validate: function (value) {
                if (value.trim() === "") return "Please enter id ";
                return true

            }

        }
    ])

    let index = Number(updData.id) - 1

    let newData = await inquirer.prompt([
        {
            type: "input",
            name: "newname",
            message: "Enter your new name",
            validate: function (value) {
                if (value.trim() === "") return "Please enter your new name"
                return true
            }
        },
        {
            type: "input",
            name: "newfather",
            message: "Enter your new father name",
            validate: function (value) {
                if (value.trim() === "") return "Please enter your new father name"
                return true
            }
        },
        {
            type: "number",
            name: "newage",
            message: "Enter your new age",
            validate: function (value) {
                if (value < 18 || value > 120) return "Please enter age 18 to 120"
                return true
            }
        }
    ])
    students[index].name = newData.newname
    students[index].father = newData.newfather
    students[index].age = newData.newage


    savestudent(students)

    console.log("Student data was updated")
    await main()

}
