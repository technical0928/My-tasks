import inquirer from "inquirer";

//Question 3
async function main() {

    let electricity = await inquirer.prompt([
        {
            type: "number",
            name: "bill",
            message: "Enter your bill",
            validate: function (value) {
                if (value < 1) return "Please enter your bill"
                return true
            }

        },
        {
            type: "number",
            name: "people",
            message: "How many people included in bills",
            validate: function (value) {
                if (value < 1) return "Please enter the people"
                return true
            }
        }
    ])
    let totalBill = 0
    let totalPeople = 0


    totalBill = totalBill + electricity.bill
    totalPeople = totalBill / electricity.people




    console.log(`Total bill is: ${totalBill}`)
    console.log(`Total bill divide by people:  ${totalPeople}`)



}

main()