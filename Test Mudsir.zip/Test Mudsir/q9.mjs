let counterApp = "Abdur rehman is good boy is very intelligent.";


let longestWord = counterApp.split(" ");

longestWord.sort((a, b) => b.length - a.length);

console.log("Longest word:", longestWord[0]);
console.log("Length:", longestWord[0].length);

// total lines
let totalLines = counterApp.trim().split("\n").length;

// total words
let totalWords = counterApp.trim().split(" ").length;

console.log(`Total lines in paragraph is: ${totalLines}`);
console.log(`Total words in paragraph is: ${totalWords}`);