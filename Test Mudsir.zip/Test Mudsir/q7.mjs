import inquirer from "inquirer";

//Question 7
async function main() {
    let user = await inquirer.prompt([
        {
            type: 'password',
            name: "password",
            message: "Enter your password",
            mask: "*",
            validate: function (value) {
                if (value.trim() === "") "Please enter your password"
                if (value.length < 8) return "Please password greater then 8 characters "
                return true

            }
        }
    ])
    if (user.password === "12345" || user.password === "abcd") {
        console.log("you password is very week")
        return main()
    } else if (user.password.length < 8) {
        console.log("your password is week")
        return main()
    } else if (!user.password.includes("@", "!", "&")) {
        console.log("your password is week please include special character Like @,&,$")
        return main()
    }
    console.log(`You password is ${user.password}`)

}
main()