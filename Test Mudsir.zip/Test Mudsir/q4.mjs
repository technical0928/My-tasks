import inquirer from "inquirer";

//question 4
async function main() {
    let question = await inquirer.prompt([
        {
            type: "rawlist",
            name: "msq1",
            message: "HTML stand for",
            choices: ["hyper text markup language", "hyper text", "markup language", "hyper markup language"]
        },
        {
            type: "rawlist",
            name: "msq2",
            message: "Pakistan capital is ",
            choices: ["Lahore", "Islamabad", "Karachi", "Peshawar"]
        },
        {
            type: "rawlist",
            name: "msq3",
            message: "2+5",
            choices: ["6", "7", "8", "9"]
        },
        {
            type: "rawlist",
            name: "msq4",
            message: "Donald trump president is",
            choices: ["Pakistan", "India", "United state of america", "Russia"]
        },
        {
            type: "rawlist",
            name: "msq5",
            message: "4+12",
            choices: ["12", "13", "15", "16"]
        },




    ])
    let correct1 = "hyper text markup language";
    let correct2 = "Islamabad";
    let correct3 = "7";
    let correct4 = "United state of america";
    let correct5 = "16";
    let count = 0
    if (question.msq1 === correct1) {
        count = count + 10

    } else {
        console.log("you are wrong choose")
    }
    //mcq2
    if (question.msq2 === correct2) {
        count = count + 10

    } else {
        console.log("you are wrong choose")
    }
    //mq3
    if (question.msq3 === correct3) {
        count = count + 10

    } else {
        console.log("you are wrong choose")
    }
    //mcq4
    if (question.msq4 === correct4) {
        count = count + 10

    } else {
        console.log("you are wrong choose")
    }
    //mcq5
    if (question.msq5 === correct5) {
        count = count + 10

    } else {
        console.log("you are wrong choose")
    }


    //percentage calculate
    if (count >= 50) {
        console.log("//Your percentage is 100% //")
        console.log("Exellent")
    } else if (count >= 40) {
        console.log("//Your percentage is 80% //")
        console.log("Good")


    } else if (count >= 30) {
        console.log("//Your percentage is 60% //")
        console.log("Not bad")


    } else if (count >= 20) {
        console.log("//Your percentage is 40% //")
        console.log("pass")
    } else if (count >= 0) {
        console.log("//Your percentage is 20% //")
        console.log("Fail")

    }

    console.log(`your marks is ${count}`)
    console.log(`Correct answer is mcq1: ${correct1}`)
    console.log(`Correct answer is mcq2: ${correct2}`)
    console.log(`Correct answer is mcq3: ${correct3}`)
    console.log(`Correct answer is mcq4: ${correct4}`)
    console.log(`Correct answer is mcq5: ${correct5}`)




}
main()

